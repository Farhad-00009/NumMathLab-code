/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cse0210.differentiation;

/**
 *
 * @author Teachers PC
 */
public abstract class PolynomialFunction {
    double x;
    abstract double getFunctionValue(double x1);
}
