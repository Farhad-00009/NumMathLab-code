/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cse0210.differentiation;

import java.util.Scanner;

/**
 *
 * @author Teachers PC
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        System.out.print("enter 1 for quadratic, enter 2 for cubic function: ");
        int option = sc.nextInt();
        if (option == 1) {
            System.out.print("Please enter a: ");
            int a = sc.nextInt();

            System.out.print("Please enter b: ");
            int b = sc.nextInt();

            System.out.print("Please enter c: ");
            int c = sc.nextInt();

            System.out.print("Please enter x: ");
            int x = sc.nextInt();

            System.out.print("Please enter del x: ");
            double delX = sc.nextDouble();

            QuadraticFunction f = new QuadraticFunction(a, b, c, x);
            System.out.println("the function is " + f);

            DifferentiationQuadratic d = new DifferentiationQuadratic(f);
            System.out.println("True value is: " + d.getTrueValue());
//==========FDD============================//
            FDD approxFDD = new FDD(f);
            System.out.println("Approx. value is: " + approxFDD.getApproxValue(delX));

            double trueErrorFDD = d.getTrueValue() - approxFDD.getApproxValue(delX);

            System.out.println("True error is: " + trueErrorFDD);
//==========BDD============================//            
            BDD approxBDD = new BDD(f);
            System.out.println("Approx. value is: " + approxBDD.getApproxValue(delX));

            double trueErrorBDD = d.getTrueValue() - approxBDD.getApproxValue(delX);

            System.out.println("True error is: " + trueErrorBDD);

//==========CDD============================//            
            CDD approxCDD = new CDD(f);
            System.out.println("Approx. value is: " + approxCDD.getApproxValue(delX));

            double trueErrorCDD = d.getTrueValue() - approxCDD.getApproxValue(delX);

            System.out.println("True error is: " + trueErrorCDD);
        } else if (option == 2) {
              System.out.print("Please enter a: ");
            int a = sc.nextInt();

            System.out.print("Please enter b: ");
            int b = sc.nextInt();

            System.out.print("Please enter c: ");
            int c = sc.nextInt();

            System.out.print("Please enter d: ");
            int d = sc.nextInt();
            
            System.out.print("Please enter x: ");
            int x = sc.nextInt();

            System.out.print("Please enter del x: ");
            double delX = sc.nextDouble();

            CubicFunction f = new CubicFunction(a, b, c, d, x);
            System.out.println("the function is " + f);

            DifferentiationCubic e = new DifferentiationCubic(f);
            System.out.println("True value is: " + e.getTrueValue());
//==========FDD============================//
            FDD approxFDD = new FDD(f);
            System.out.println("Approx. value is: " + approxFDD.getApproxValue(delX));

            double trueErrorFDD = e.getTrueValue() - approxFDD.getApproxValue(delX);

            System.out.println("True error is: " + trueErrorFDD);
//==========BDD============================//            
            BDD approxBDD = new BDD(f);
            System.out.println("Approx. value is: " + approxBDD.getApproxValue(delX));

            double trueErrorBDD = e.getTrueValue() - approxBDD.getApproxValue(delX);

            System.out.println("True error is: " + trueErrorBDD);

//==========CDD============================//            
            CDD approxCDD = new CDD(f);
            System.out.println("Approx. value is: " + approxCDD.getApproxValue(delX));

            double trueErrorCDD = e.getTrueValue() - approxCDD.getApproxValue(delX);

            System.out.println("True error is: " + trueErrorCDD);
        }

    }

}
