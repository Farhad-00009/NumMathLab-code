/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cse0210.differentiation;

/**
 *
 * @author Teachers PC
 */
public class BDD {
    PolynomialFunction p;
    BDD(PolynomialFunction f){
        p = f;
    }
    
    double getApproxValue(double delX){
        double approxValue = (p.getFunctionValue(p.x) - p.getFunctionValue(p.x-delX)) / delX;
        return approxValue;
    }
}
