/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cse0210.differentiation;

/**
 *
 * @author Teachers PC
 */
public class CubicFunction extends PolynomialFunction{
    double a, b, c, d;
    CubicFunction(double p, double q, double r, double s, double t){
        a = p;
        b = q;
        c = r;
        d = s;
        x = t;
    }
    
    @Override
    public String toString(){
        String s = a + "x^3 + " + b + "x^2 + " + c + "x + " + d;
        return s;
    }
    
    @Override
    double getFunctionValue(double x1){
        double ans = a * x1 * x1 * x1 + b * x1 * x1 + c * x1 + d;
        return ans;
    }
}
