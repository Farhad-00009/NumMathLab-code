/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cse0210.differentiation;

/**
 *
 * @author Teachers PC
 */
public class QuadraticFunction extends PolynomialFunction{
    double a, b, c;
    QuadraticFunction(double p, double q, double r, double s){
        a = p;
        b = q;
        c = r;
        x = s;
    }
    
    @Override
    public String toString(){
        String s = a + "x^2 + " + b + "x + " + c;
        return s;
    }
    
    @Override
    double getFunctionValue(double x1){
        double ans = a * x1 * x1 + b * x1 + c;
        return ans;
    }
}
