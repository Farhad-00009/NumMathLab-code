/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cse0210.differentiation;

/**
 *
 * @author Teachers PC
 */
public class DifferentiationQuadratic {

    QuadraticFunction p;

    DifferentiationQuadratic(QuadraticFunction f) {
        p = f;
    }

    double getTrueValue() {
        double trueValue = 2 * p.a * p.x + p.b;
        return trueValue;
    }
}
